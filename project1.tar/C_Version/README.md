<h3>C Version</h3>

<p>This version of project one uses the UNIX socket API to solve the client server problem</p>

<p>client_code/ contains the code for the client</p>
<p>server_code/ contains the code for the server</p>
<p>Within both of those directories there is a folder named test. I am currently using this for received files</p>

<p>Running make compiles both the client, and the server. In addition to compiling each program, it places the <br>
executables in their respective folders</p>
