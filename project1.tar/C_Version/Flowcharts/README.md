<h3>Flowcharts</h3>

<p>This folder contains my flowcharts for the client and server programs I have written.<br>
I used the draw.io program to construct these diagrams. Go [here](https://app.diagrams.net/) to <br>
access them.</p>

<p>Features that have yet to be implemented are colored red.</p>

<p>The client server communication diagram shows how the client and server communicate and how<br>
they go about exchanging files with each other.</p>

<p>The client main and server main diagrams show more specific details about the operation of each<br>
program alone</p>

<p>The most crucial diagram is the client server diagram as it shows how the two actually talk to each other.</p>
